CREATE PROCEDURE sp_users_save(IN pdesperson VARCHAR(64), IN pdeslogin VARCHAR(64), IN pdespassword VARCHAR(256),
                               IN pdesemail  VARCHAR(128), IN pnrphone BIGINT, IN pinadmin TINYINT)
  BEGIN
 
    DECLARE vidperson INT;
    
 INSERT INTO tb_persons (desperson, desemail, nrphone)
    VALUES(pdesperson, pdesemail, pnrphone);
    
    SET vidperson = LAST_INSERT_ID();
    
    INSERT INTO tb_users (idperson, deslogin, despassword, inadmin)
    VALUES(vidperson, pdeslogin, pdespassword, pinadmin);
    
    SELECT * FROM tb_users a INNER JOIN tb_persons b USING(idperson) WHERE a.iduser = LAST_INSERT_ID();
    
END;
